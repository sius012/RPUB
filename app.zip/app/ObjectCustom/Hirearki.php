<?php
namespace App\ObjectCustom;

class Hirearki {
    public $data;
    public $children = [];
}

?>