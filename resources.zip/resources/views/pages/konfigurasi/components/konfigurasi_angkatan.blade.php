<div class="container flex-grow-1 container">
    <div class="row">
        <div class="button"><button type="button" class="btn btn-primary mb-5" data-bs-toggle="modal" data-bs-target="#basicModal" id="tambah-angkatan">
                Tambah
            </button></div>

        <div class="konfigurate_angkatan">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Angkatan</th>
                        <th>Tanggal Masuk</th>
                        <th>Tanggal Keluar</th>
                        <th>Jumlah Anak</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <tr>
                        <td>1</td>
                        <td>11</td>
                        <td>24-09-2021</td>
                        <td>24-05-2024</td>
                        <td>94</td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i>
                                        Delete</a>
                                </div>
                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>