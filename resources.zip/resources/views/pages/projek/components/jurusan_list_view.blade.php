
<div class="content-wrapper" id="jurusan-list-view">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">


              <div class="row">
                <div class="col-md-12">


                   {{--  button tambah projek  --}}
                        <!-- <button type="button" class="btn btn-primary tambah-jurusan mb-3" data-bs-toggle="modal" data-bs-target="#basicModal" id="tambah-jurusan">
                          Tambah Kompetensi Keahlian
                        </button>  -->

                  {{--  -----card projek jurusan--- note(nanti cardnya ini pake foreach)  --}}
                  <div class="row row-jurusan">

                  </div>
                  </div>
                {{--  -----/card projek jurusan---  --}}

                </div>
              </div>
            </div>
            <!-- / Content -->
            <div class="content-backdrop fade"></div>
          </div>
