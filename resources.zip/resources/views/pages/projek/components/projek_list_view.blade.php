<div class="container-fluid" id="projek-list-view">

    <div class="row">
        <div class="col-md-12">
            {{-- button tambah projek  --}}
            <div class="row">
                <div class="col">
                    <button type="button" class="btn btn-primary tambah-projek mb-3" data-bs-toggle="modal" data-bs-target="#basicModal">
                        Tambah Projek
                    </button>
                </div>
                <div class="col"><select name="" id="" class="filter-jurusan form-control">
                    </select></div>
            </div>



            {{-- -----card projek jurusan--- note(nanti cardnya ini pake foreach)  --}}
            <div class="row row-view">

            </div>

        </div>
        {{-- -----/card projek jurusan---  --}}

    </div>
</div>
</div>
<!-- / Content -->



<div class="content-backdrop fade"></div>
</div>


<script type="text/javascript">
    var link = document.getElementById('click');
</script>