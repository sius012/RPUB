<div class="container siswa-jurusan-view">
    <div class="row"></div>
</div>