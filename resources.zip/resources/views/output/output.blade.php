<!DOCTYPE html>
<html>

<head>
    <title>Belajar Membuat Tabel HTML</title>
</head>

<body>
    <table border="1" bgcolor="white" align="center">
        
        <tr>
            <th rowspan="2">Nilai Nonformal (Kompeten/Tidak Kompeten)</th>
            <th colspan="3">Penilaian Informal</th>
        </tr>
        <tr bgcolor="gray">
            <th>Inisiatif</th>
            <th>Antusias</th>
            <th>Kejujuran</th>
            <th>Kreatifitas</th>
            <th>Kedisiplinan</th>
            <th>Tanggung Jawab</th>
            <th>Komunikasi</th>
            <th>Etika & Sopan Santun</th>
            <th>Kecepatan, Ketepatan & Kerapian</th>
        </tr>
        
        <tr>
            <td align="center" valign="middle" width="180" height="40">90</td>
            <td align="center" valign="middle">B</td>
            <td align="center" valign="middle">B</td>
            <td align="center" valign="middle">B</td>
            <td align="center" valign="middle">B</td>
            <td align="center" valign="middle">B</td>
            <td align="center" valign="middle">B</td>
            <td align="center" valign="middle">B</td>
            <td align="center" valign="middle">B</td>
            <td align="center" valign="middle">B</td>
        </tr>
        
    </table>
</body>
</html>