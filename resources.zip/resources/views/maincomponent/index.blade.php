<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
</head>

<body>
    @include("maincomponent.siswaModal")

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $(".form-group").on("dragstart", function() {
                $(this).addClass("dragging")
            })

            $(".form-group").on("dragend", function() {
                $(this).removeClass("dragging")
            })

            $(".modal-body").on("dragover", function(e) {
                e.preventDefault();
                const afterElements = getDragAfterElement(this, e.clientY);

            })

            function getDragAfterElement(container, y) {
                const draggableElements = [...container.querySelectorAll('draggable:not(.dragging)')]

                draggableElements.reduce((closest, child) => {
                    const box = child.getBoundingClientRect()
                    console.log(box);
                }, {
                    offset: Number.POSITIVE_INFINITY
                })
            }
        })
    </script>
</body>

</html>